# ABANDONED: OWASP PHP Security Project

## You can still find the [old source tree](https://github.com/OWASP/phpsec/tree/1999edc10a3b755ff2b17bb78376bd53dd40d192), but please be careful. There are many [known issues](https://github.com/OWASP/phpsec/issues).

The OWASP PHP Security Project was an effort by a group of PHP developers to help secure PHP web applications. The aim was to provide a collection of decoupled, flexible, secure PHP libraries, as well as a collection of PHP tools.

Unfortunately, due to a number of circumstances, the project did not manage to meet these objectives.

Because the code base that was under development was full of serious security issues, the decision was made to delete the code from this repository. The hope is that this will prevent developers from using the code or attempting to learn from it.

If you really do need to retrieve any of the code that once lived here, or if you wish to make an attempt at resurrecting the project, you can use the [source tree before the project was abandoned](https://github.com/OWASP/phpsec/tree/1999edc10a3b755ff2b17bb78376bd53dd40d192).

## Links

* Official Website: [phpsec.owasp.org](http://phpsec.owasp.org)
* Official Wiki page: [owasp.org/phpsec](https://owasp.org/index.php/phpsec)

## Contributors

* Rahul Chaudhary
* Abbas Naderi
* Abhishek Das
* Shivam Dixit
* Achim
* Zaki Akhmad
* A V Minhaz
* Paulo Guerreiro
