//Full Name: Abhi Jay Krishnan

//Programe to print out the score for a diving competition 
//It includes:-
//1. Read score given by 4 judges 
//   and the difficulty level of the dive
//2. Exclude the lowest and highest score given by
//   the judges while computing the score.
//   * Print out the highest and lowest score are being eliminated.
//   * calculate the score.
//3.Print out the final summary table:
//  Summary Table
//  =================
//  judge  Result  Remark
//   **     ***     
//   **     ****     ***
//   **     ***     ****
//   **     ***     
//  degree of difficulty:**
//  final score :**

#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

float getScore (int);
int getMaxJudge (float, float, float, float);
int getMinJudge (float, float, float, float, int);
float getResult (float, float, float, float, int, int, float);
void displayResult (float, float, float, float, int, int, float, float);

int main()
{
	float score1 , score2, score3, score4, difficulty;
	int max_judge, min_judge;
	float final_score;

	score1 = getScore(1);
	score2 = getScore(2);
	score3 = getScore(3);
	score4 = getScore(4);
	difficulty = getScore(5);
	
	max_judge = getMaxJudge(score1, score2, score3, score4);
	cout<<endl<<"Judge "<<max_judge<<" maximum score eliminated"<<endl; 
	
	min_judge = getMinJudge(score1, score2, score3, score4, max_judge);
	cout<<endl<<"Judge "<<min_judge<<" minimum score eliminated"<<endl;
	
	final_score = getResult(score1, score2, score3, score4, max_judge, min_judge, difficulty);
	
	displayResult(score1, score2, score3, score4, max_judge, min_judge , difficulty, final_score);
	
	return 0;
}

//======================================================
//Get score and difficulty of dive from user

float getScore(int n)
{
	float score;
	if (n >= 1 && n <= 4)
	{
		do
		{
			cout<<"Enter judge "<<n<<" score (1 to 10) : ";
			cin>>score;
		}while(score > 10 || score < 0);
	}

	else if(n == 5)
	{
		do
		{
			cout<<"Enter degree of difficulty (1.6 to 3.9): ";
			cin>>score;
			//cout<<endl;
		}while(score < 1.6 || score > 3.9);
	}
	return score;
}

//====================================================
//Find which judge gave the maximum score

int getMaxJudge(float score1, float score2, float score3, float score4)
{
	int max_judge;
	float largest_score;
	
	largest_score = score1;
	max_judge = 1;
	
	if (score1 == score2 && score2 == score3 && score3 == score4)
	{
		max_judge = 1;
	}
	else
	{	 
	 	if(score2 > largest_score)
		{
			largest_score = score2;
			max_judge = 2;
		}
		if(score3 > largest_score)
		{
			largest_score = score3;
			max_judge = 3;
		}
		if(score4 > largest_score)
		{
			largest_score = score4;
			max_judge = 4;
		}
	}
	
	return max_judge;
} 

//====================================================
//Find which judge gave the maximum score

int getMinJudge (float score1, float score2, float score3, float score4, int max_judge)
{
	int min_judge = 0;
	float score[]={score1 , score2, score3 , score4};
	float smallest = score[max_judge-1];
	
	if (score[0] == score[1] && score[1] == score[2] && score[2] == score[3])
		{
			min_judge = 4;
		}
	else
	{	 
		for(int i = 0; i <= 3; i++)
		{
			
			if(score[i] != score[max_judge-1]) 
			{
				if(score[i] < smallest)
				{
					smallest = score[i];
					min_judge = i+1;
				}
			}
		}
	}
	
	return min_judge;
	
}

//===================================================
//Calculate the total score

float getResult (float score1, float score2,  float score3, float score4, int max_judge, int min_judge, float difficulty)
{
	float score[] = {score1, score2, score3 , score4};
	float sum=0, final_score=0;
	
	for(int i=0 ; i <= 3; i++)
	{
		if(i != (max_judge-1) && i != (min_judge-1))
		{
			sum = sum + score[i];
		}
	}
	
	final_score = sum * difficulty;
	
	return final_score;
}

//===================================================
//Display the summary table and the final score

void displayResult (float score1, float score2, float score3, float score4, int max_judge, int min_judge, float difficulty, float final_score)
{
	float score[] = {score1, score2, score3 , score4};
	char item_max[8] , item_min[8];
		
	for(int i=0; i <= 3; i++)
	{
		if(i == (max_judge-1))
		{
			strcpy(item_max,"MAX (X)");
		}
	}
	
	for(int i=0; i <= 3; i++)
	{
		if(i == (min_judge-1))
		{
			strcpy(item_min,"MIN (X)");
		}
	}
	
	cout<<fixed<<showpoint<<setprecision(1);
	
	cout<<endl;
	cout<<"Summary Table";
	cout<<endl;
 	cout<<setw(13)<<setfill('=')<<"="
	    <<setfill(' ')
		<<endl;
		
	cout<<left<<setw(10)<<"Judge"                       
     	<<left<<setw(8)<<"Result"
	 	<<left<<setw(8)<<"Remark"
	 	<<endl;
		
	for(int i=0; i <= 3; i++)
	{
		if(i != (max_judge - 1) && i != (min_judge - 1))
		{
			cout<<left<<setw(10)<<i+1                       
     			<<left<<setw(8)<<score[i]
	 			<<endl;
		}
	    else if(i == (max_judge - 1))
		{
			cout<<left<<setw(10)<<i+1                       
     			<<left<<setw(8)<<score[i]
				<<left<<setw(8)<<item_max
	 			<<endl;
		}
		else if(i == (min_judge - 1))
		{
			cout<<left<<setw(10)<<i+1                       
     			<<left<<setw(8)<<score[i]
				<<left<<setw(8)<<item_min
	 			<<endl;
		}
	}
	
	cout<<endl;
	
	cout<<"Degree of difficulty: "
		<<difficulty<<endl;
	cout<<"Final score: "
		<<final_score<<endl;
}	 	 
	
	
			   
			
		
		

		
	
	

